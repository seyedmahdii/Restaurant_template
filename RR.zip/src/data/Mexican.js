export default [
    {
        id: 1,
        name: "Gordita Taco Combo",
        image: "https://cdn.opeqe.com/image/menu/s/9.jpg",
        category: "Taco",
        tags: ["Mexican", "Main Course", "Lunch & Dinner"],
        time: "15-22 Mins",
        price: 9.89,
        feature: "Free Pickup",
    },
];
