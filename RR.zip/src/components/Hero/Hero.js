import React from "react";
import "./Hero.css";
// import Hero from "../../images/Hero.jpg";

function Hero() {
    return <div className="hero"></div>;
}

export default Hero;
